package com.example.mobliefinal

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentStatePagerAdapter


class RankPagerAdapter(fm: FragmentManager, private val topicId: String, private val username: String) :
    FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getItem(position: Int): Fragment {
        // Tạo các fragment mới và truyền dữ liệu vào đây
        return when (position) {
            0 -> FragmentRank.newInstance(topicId, username)
            1 -> FragmentLearnedGuest.newInstance(topicId, username)
            // Thêm các case khác nếu có nhiều fragment hơn
            else -> throw IllegalArgumentException("Invalid position")
        }
    }

    override fun getCount(): Int {
        return 2 // Số lượng fragment, bạn có thể thay đổi tùy thuộc vào số lượng fragment bạn có
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Highest Score"
            1 -> "Learn The Most"
            // Thêm các title khác nếu có nhiều fragment hơn
            else -> null
        }
    }
}


