package com.example.mobliefinal

class Word (
    val wordId: String? = null,
    val createdAt: Long = 0,
    val meaning: String = "",
    val word: String = "",
    val topic: String = "",
    val learned: Long = 0,
    var back: Boolean = false,
    var learn: Boolean = false,
    var memorize: Boolean = false,
    val userTopic: String = "",
    var correct: Boolean = false,
    var favorite: Boolean = false
)
