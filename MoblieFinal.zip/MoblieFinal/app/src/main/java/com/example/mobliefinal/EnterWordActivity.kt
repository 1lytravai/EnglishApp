package com.example.mobliefinal

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.ToggleButton
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.firebase.database.*

class EnterWordActivity : AppCompatActivity() {

    private lateinit var tvWord: TextView
    private lateinit var etUserInput: EditText
    private lateinit var btnSubmit: Button
    private lateinit var container: RelativeLayout

    private var wordList: MutableList<Word> = mutableListOf()
    private var currentWordIndex: Int = 0
    private lateinit var databaseReference: DatabaseReference
    private val handler = Handler()

    private var correctAnswers: Int = 0
    private var incorrectAnswers: Int = 0

    private var isViewingMeaning: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // ... existing code ...


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_word)

        tvWord = findViewById(R.id.tvWord)
        etUserInput = findViewById(R.id.etUserInput)
        btnSubmit = findViewById(R.id.btnSubmit)
        container = findViewById(R.id.container)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }
        // Lấy reference của cơ sở dữ liệu "words"
        databaseReference = FirebaseDatabase.getInstance().getReference("words")

        val toggleMeaningWord: ToggleButton = findViewById(R.id.toggleMeaningWord)

        // Lấy topicId từ Intent
        val topicId = intent.getStringExtra("topicId")

        // Lấy danh sách từ vựng

        val isFavorite = intent.getBooleanExtra("favorite", false)

        isViewingMeaning = !toggleMeaningWord.isChecked

        if (isFavorite) {
            fetchFavoriteWordsList(topicId)
        } else {
            fetchWordsList(topicId)
        }

        toggleMeaningWord.setOnCheckedChangeListener { _, isChecked ->
            toggleMeaningWord.isEnabled = false
            isViewingMeaning = !isChecked
            if (isViewingMeaning) {
                if (isFavorite) {
                    fetchFavoriteMeaningList(topicId)
                } else {
                    fetchMeaningList(topicId)
                }
            } else {
                // Nếu đang xem từ vựng, thực hiện fetchWordsList
                if (isFavorite) {
                    fetchFavoriteWordsList(topicId)
                } else {
                    fetchWordsList(topicId)
                }
            }
        }

        // Cập nhật ToggleButton dựa trên giá trị của isViewingMeaning
        toggleMeaningWord.isChecked = !isViewingMeaning

        btnSubmit.setOnClickListener {
            checkAnswer(topicId)
        }
    }

    private fun fetchWordsList(topicId: String?) {
        // Truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayWord()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle the error if the query is not successful
                // Toast.makeText(this@EnterWordActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun fetchFavoriteWordsList(topicId: String?) {
        // Lấy reference của cơ sở dữ liệu "words"
        val wordsReference = FirebaseDatabase.getInstance().getReference("words")
        val query = wordsReference.orderByChild("topic").equalTo(topicId)

        // Thực hiện truy vấn để lấy danh sách từ vựng với điều kiện favorite = true
        wordsReference.orderByChild("favorite").equalTo(true).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()

                // Lặp qua danh sách từ vựng và thêm vào wordList
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayWord()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi nếu truy vấn không thành công
                // Toast.makeText(this@EnterWordActivity, "Error fetching favorite words", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun displayWord() {
        // Hiển thị từ (word)
        tvWord.text = wordList[currentWordIndex].word
    }


    private fun checkAnswer(topicId: String?) {
        val userInput = etUserInput.text.toString().trim()
        val isCorrect = userInput.equals(wordList[currentWordIndex].meaning, ignoreCase = true)

        // Set background color based on correctness
        val backgroundColor = if (isCorrect) Color.GREEN else Color.RED
        container.setBackgroundColor(backgroundColor)

        // Increment the counters based on correctness
        if (isCorrect) {
            correctAnswers++
            updateIsMemorize(wordList[currentWordIndex].wordId)
            updateIsCorrect(wordList[currentWordIndex].wordId, true)

        } else {
            incorrectAnswers++
            updateIsCorrect(wordList[currentWordIndex].wordId, false)
        }

        // Delay for 1 second and then move to the next word or show final results
        handler.postDelayed({
            // Reset background color
            container.setBackgroundColor(Color.TRANSPARENT)

            // Move to the next word or show final results
            currentWordIndex++
            if (currentWordIndex < wordList.size) {
                displayWord()
            } else {
                showFinalResults()
            }
        }, 1000)

        etUserInput.text.clear()
    }

    private fun fetchMeaningList(topicId: String?) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")

        // Truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayMeaningAndWords()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle the error if the query is not successful
                // Toast.makeText(this@EnterWordActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun displayMeaningAndWords() {
        // Hiển thị nghĩa từ (meaning)
        val meaningTextView: TextView = findViewById(R.id.tvWord)
        meaningTextView.text = wordList[currentWordIndex].meaning

        btnSubmit.setOnClickListener {
            checkWord()
        }
    }

    private fun checkWord() {
        val userInput = etUserInput.text.toString().trim()
        val correctWord = wordList[currentWordIndex].word.trim()

        // Check if the entered word is correct
        val isCorrect = userInput.equals(correctWord, ignoreCase = true)

        // Set background color based on correctness
        val backgroundColor = if (isCorrect) Color.GREEN else Color.RED
        container.setBackgroundColor(backgroundColor)

        // Increment the counters based on correctness
        if (isCorrect) {
            correctAnswers++
        } else {
            incorrectAnswers++
        }

        // Delay for 1 second and then move to the next word or show final results
        handler.postDelayed({
            // Reset background color
            container.setBackgroundColor(Color.TRANSPARENT)

            // Move to the next word or show final results
            currentWordIndex++
            if (currentWordIndex < wordList.size) {
                displayMeaningAndWords()
            } else {
                showFinalResults()
            }
        }, 1000)

        etUserInput.text.clear()
    }
    private fun fetchFavoriteMeaningList(topicId: String?) {
        // Lấy reference của cơ sở dữ liệu "words"
        val wordsReference = FirebaseDatabase.getInstance().getReference("words")
        val query = wordsReference.orderByChild("topic").equalTo(topicId)

        // Thực hiện truy vấn để lấy danh sách từ vựng với điều kiện favorite = true
        wordsReference.orderByChild("favorite").equalTo(true).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()

                // Lặp qua danh sách từ vựng và thêm vào wordList
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayMeaningAndWords()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi nếu truy vấn không thành công
                // Toast.makeText(this@EnterWordActivity, "Error fetching favorite words", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun updateIsMemorize(wordId: String?) {
        wordId?.let {
            val databaseReference: DatabaseReference =
                FirebaseDatabase.getInstance().getReference("words").child(wordId)
            databaseReference.child("memorize").setValue(true)
        }
    }
    private fun updateIsCorrect(wordId: String?, correct: Boolean) {
        wordId?.let {
            val databaseReference: DatabaseReference =
                FirebaseDatabase.getInstance().getReference("words").child(wordId)
            databaseReference.child("correct").setValue(correct)
        }
    }
    private fun resetCorrectStatus() {
        for (word in wordList) {
            updateIsCorrect(word.wordId, false)
        }
    }
    private fun showFinalResults() {
        // Hiển thị số câu đúng và số câu sai
        val resultMessage = "Number of correct: $correctAnswers\nNumber of wrong: $incorrectAnswers"
        // Ví dụ: Hiển thị thông báo cuối cùng bằng Dialog hoặc Toast
        // Toast.makeText(this@EnterWordActivity, resultMessage, Toast.LENGTH_LONG).show()
        // Hoặc sử dụng AlertDialog để hiển thị kết quả cuối cùng
        val alertDialog = AlertDialog.Builder(this@EnterWordActivity)
            .setTitle("Result")
            .setMessage(resultMessage)
            .setPositiveButton("OK") { _, _ ->
                resetCorrectStatus()
                val intent = Intent(this@EnterWordActivity, MainActivity::class.java)
                startActivity(intent)
            }
            .create()
        alertDialog.show()
    }
    private fun shuffleWordList() {
        wordList.shuffle()
    }

}
