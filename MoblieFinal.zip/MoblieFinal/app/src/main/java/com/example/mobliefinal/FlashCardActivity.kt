package com.example.mobliefinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.viewpager.widget.ViewPager
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FlashCardActivity : AppCompatActivity(), FlashCardAdapter.LearningProgressListener {
    private lateinit var viewPager: ViewPager
    private lateinit var flashCardAdapter: FlashCardAdapter
    private var words: List<Word> = ArrayList()
    private lateinit var learningProgressTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flash_card)
        FirebaseApp.initializeApp(this)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }


        learningProgressTextView = findViewById(R.id.learningProgressTextView)

        val topicId = intent.getStringExtra("topicId")

        val isFavorite = intent.getBooleanExtra("favorite", false)

        if (isFavorite) {

            fetchFavoriteFlashcards(topicId)
        } else {
            // Fetch all flashcards
            fetchWords(topicId)
        }
    }

    private fun fetchWords(topic: String?) {
        val words: MutableList<Word> = mutableListOf()
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")
        val query = databaseReference.orderByChild("topic").equalTo(topic)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (snapshot in dataSnapshot.children) {
                    val name = snapshot.child("word").getValue(String::class.java)
                    val meaning = snapshot.child("meaning").getValue(String::class.java)
                    val wordId = snapshot.key

                    if (name != null && meaning != null && wordId != null) {
                        words.add(Word(wordId = wordId, word = name, meaning = meaning))
                    }
                }

                // Update UI and learning progress after fetching data
                updateUI(words)
                updateLearningProgress()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
            }
        })
    }

    private fun fetchFavoriteFlashcards(topicId: String?) {
        val favoriteFlashcards: MutableList<Word> = mutableListOf()
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")
        val query = databaseReference.orderByChild("topic").equalTo(topicId)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (snapshot in dataSnapshot.children) {
                    val name = snapshot.child("word").getValue(String::class.java)
                    val meaning = snapshot.child("meaning").getValue(String::class.java)
                    val wordId = snapshot.key
                    val isFavorite = snapshot.child("favorite").getValue(Boolean::class.java)

                    if (name != null && meaning != null && wordId != null && isFavorite == true) {
                        favoriteFlashcards.add(Word(wordId = wordId, word = name, meaning = meaning))
                    }
                }

                // Update UI and learning progress after fetching data
                updateUI(favoriteFlashcards)
                updateLearningProgress()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
            }
        })
    }

    private fun updateUI(words: List<Word>) {
        viewPager = findViewById(R.id.viewPager)
        flashCardAdapter = FlashCardAdapter(words, viewPager, this)
        viewPager.adapter = flashCardAdapter

        // Notify the adapter of the data set change
        flashCardAdapter.notifyDataSetChanged()
    }

    private fun updateLearningProgress() {
        Log.d("FlashCardActivity", "Update Learning Progress")
        val totalWords = words.size
        val learnedWords = words.count { it.learn }

        val progressText = "$learnedWords/$totalWords"
        learningProgressTextView.text = progressText
    }
    override fun onLearningProgressChanged() {
        updateLearningProgress()
    }
}