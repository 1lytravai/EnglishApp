package com.example.mobliefinal

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment

class MultipleDialogFragmentGuest : DialogFragment() {
    private lateinit var btnViet: Button
    private lateinit var btnEng: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.multiple_choice_dialog, container, false)

        btnViet = view.findViewById(R.id.btnViet)
        btnEng = view.findViewById(R.id.btnEng)

        // Retrieve data from arguments
        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val username = arguments?.getString("username")

        btnViet.setOnClickListener {
            // Handle the "Normal" button click with the passed data
            // For example, start the Flashcard activity with the data
            val intent = Intent(requireContext(), MultipleChoiceGuestActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("username", username)
            intent.putExtra("eng", false) // Set to false for normal flashcards
            startActivity(intent)
            dismiss()
        }
        btnEng.setOnClickListener {
            val intent = Intent(requireContext(), MultipleChoiceGuestActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("username", username)
            intent.putExtra("eng", true) // Set to true for favorite flashcards
            startActivity(intent)
            dismiss() // Close the dialog after handling the click
        }

        // Add any logic for the "Favorite" button if needed

        return view
    }

}
