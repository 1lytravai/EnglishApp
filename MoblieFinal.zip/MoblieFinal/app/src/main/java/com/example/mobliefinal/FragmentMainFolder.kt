package com.example.mobliefinal

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobliefinal.databinding.FragmentMainFolderBinding
import com.google.firebase.database.*

class FragmentMainFolder : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var topicList: ArrayList<Topic>
    private lateinit var topicAdapter: TopicAdapter
    private lateinit var databaseReference: DatabaseReference
    private var _binding: FragmentMainFolderBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainFolderBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val folderId = arguments?.getString("folderId")
        recyclerView = binding.recyclerViewTopic
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        databaseReference = FirebaseDatabase.getInstance().reference.child("topics")

        topicList = ArrayList()
        topicAdapter = TopicAdapter(requireActivity(), topicList, folderId ?: "")
        recyclerView.adapter = topicAdapter

        // Load danh sách chủ đề
        loadTopicsForFolder(folderId)
    }

    private fun loadTopicsForFolder(folderId: String?) {
        if (!folderId.isNullOrEmpty()) {
            databaseReference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    topicList.clear()
                    for (postSnapshot in snapshot.children) {
                        val topic = postSnapshot.getValue(Topic::class.java)
                        topic?.let {
                            if (it.folder == folderId) {
                                topicList.add(it)
                            }
                        }
                    }
                    topicAdapter.notifyDataSetChanged()
                    Log.d("Firebase", "Data loaded successfully")
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("Firebase", "Error loading data: ${error.message}")
                }
            })
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
