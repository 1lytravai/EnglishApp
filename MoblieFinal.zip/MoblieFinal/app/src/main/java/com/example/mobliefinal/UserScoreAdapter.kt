package com.example.mobliefinal

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class UserScoreAdapter :
    RecyclerView.Adapter<UserScoreAdapter.UserScoreViewHolder>() {

    private var scoreList: List<TopicGuest> = emptyList()

    fun setData(newData: List<TopicGuest>) {
        scoreList = newData
        notifyDataSetChanged()
        Log.d("UserScoreAdapter", "Data set: $newData")
    }

    class UserScoreViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val usernameTextView: TextView = itemView.findViewById(R.id.usernameTextView)
        val scoreTextView: TextView = itemView.findViewById(R.id.scoreTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserScoreViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_user_score, parent, false)
        return UserScoreViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UserScoreViewHolder, position: Int) {
        val topicGuest = scoreList[position]
        holder.usernameTextView.text = topicGuest.userGuest
        holder.scoreTextView.text = topicGuest.score.toString()
    }

    override fun getItemCount(): Int {
        return scoreList.size
    }
}

