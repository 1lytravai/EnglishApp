package com.example.mobliefinal

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mobliefinal.databinding.FragmentStorageBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FragmentStorage : Fragment() {
    private lateinit var binding: FragmentStorageBinding
    private lateinit var storageAdapter: StorageAdapter
    private lateinit var sharedPreferences: SharedPreferences


    private val databaseReferenceGuest = FirebaseDatabase.getInstance().reference.child("topic_guest")
    private val databaseReferenceTopics = FirebaseDatabase.getInstance().reference.child("topics")

    private lateinit var username: String

    companion object {
        fun newInstance(username: String): FragmentStorage {
            val fragment = FragmentStorage()
            val bundle = Bundle().apply {
                putString("username", username)
            }
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStorageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Nhận dữ liệu từ bundle
        val bundle = arguments
        if (bundle != null) {
            username = bundle.getString("username", "") ?: ""
        }

        // Initialize the adapter
        storageAdapter = StorageAdapter(requireActivity())

        sharedPreferences = requireActivity().getSharedPreferences(FragmentProfile.USER_PREFS, Context.MODE_PRIVATE)
        val username = sharedPreferences.getString(FragmentProfile.USERNAME_KEY, "")

        binding.recyclerViewStorage.adapter = storageAdapter
        binding.recyclerViewStorage.layoutManager = LinearLayoutManager(requireContext())

        // Thực hiện truy vấn vào Firebase để lấy danh sách các topic_guest của user hiện tại
        databaseReferenceGuest.orderByChild("userGuest").equalTo(username)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshotGuest: DataSnapshot) {
                    val topicGuests = mutableListOf<TopicGuest>()

                    // Lặp qua các topic_guest của user hiện tại
                    for (guestSnapshot in dataSnapshotGuest.children) {
                        val topicGuest = guestSnapshot.getValue(TopicGuest::class.java)
                        topicGuest?.let {
                            topicGuests.add(it)
                        }
                    }

                    // Lấy thông tin của từng topic dựa trên topicId
                    for (topicGuest in topicGuests) {
                        databaseReferenceTopics.child(topicGuest.topicId)
                            .addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(dataSnapshotTopic: DataSnapshot) {
                                    val topic = dataSnapshotTopic.getValue(Topic::class.java)

                                    // Add your logic to handle the retrieved topic data
                                    topic?.let {
                                        // Do something with the topic data
                                        // For example, add it to a list and update the adapter
                                        storageAdapter.addTopic(it)
                                    }
                                }

                                override fun onCancelled(databaseErrorTopic: DatabaseError) {
                                    // Handle errors
                                    Log.e("FragmentStorage", "Query cancelled: ${databaseErrorTopic.message}")
                                }
                            })
                    }
                }

                override fun onCancelled(databaseErrorGuest: DatabaseError) {
                    // Handle errors
                    Log.e("FragmentStorage", "Query cancelled: ${databaseErrorGuest.message}")
                }
            })
    }
}
