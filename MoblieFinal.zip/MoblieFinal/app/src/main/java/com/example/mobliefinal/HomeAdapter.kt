package com.example.mobliefinal

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date

class HomeAdapter(private val activity: Activity,
                  private val topicList: List<Topic>,
                  private val username: String
) : RecyclerView.Adapter<HomeAdapter.TopicViewHolder>() {

    class TopicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewTopicName: TextView = itemView.findViewById(R.id.tvNameTopic)
        val textViewTopicDescription: TextView = itemView.findViewById(R.id.tvDescription)
        val textViewUser: TextView = itemView.findViewById(R.id.tvUsername)
        val cardView: LinearLayout = itemView.findViewById(R.id.cardView)
        val tvCreateAt: TextView = itemView.findViewById(R.id.tvCreateAt)
        val ivStar: ImageView = itemView.findViewById(R.id.ivStar)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopicViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_home, parent, false)
        return TopicViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: TopicViewHolder, position: Int) {
        val currentTopic = topicList[position]
        holder.textViewTopicName.text = currentTopic.name
        holder.textViewTopicDescription.text = currentTopic.description
        holder.textViewUser.text = currentTopic.user
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")  // You can customize the format
        val date = Date(currentTopic.createTime as Long)
        val formattedDate = dateFormat.format(date)
        holder.tvCreateAt.text = formattedDate

        Log.d("HomeAdapter", "currentUser: $username")

        holder.cardView.setOnClickListener {
            val intent = Intent(activity, MainTopicGuestActivity::class.java)

            intent.putExtra("topicId", currentTopic.topicId)
            intent.putExtra("topicName", currentTopic.name)
            intent.putExtra("username", username)
            activity.startActivity(intent)
        }

        // Lấy reference đến topic_guest cho user hiện tại và topic hiện tại

        holder.ivStar.setOnClickListener {
            val topicGuestRef = FirebaseDatabase.getInstance().reference
                .child("topic_guest")
                .child("${currentTopic.topicId}_${username}")

            topicGuestRef.runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    val isStored = currentData.child("storage").getValue(Boolean::class.java) ?: false

                    // Check if the node exists by checking if the storage field is not null
                    if (currentData.child("storage").value != null) {
                        // Node exists, update storage
                        currentData.child("storage").value = !isStored
                    } else {
                        // Node does not exist, create a new one
                        val topicGuestId = "${currentTopic.topicId}_$username"
                        currentData.value = TopicGuest(
                            topicGuestId = topicGuestId,
                            topicId = currentTopic.topicId ?: "",
                            userGuest = username,
                            score = 0,
                            learned = 0,
                            storage = true // You can set the initial value as needed
                        )
                    }
                    return Transaction.success(currentData)
                }

                override fun onComplete(
                    databaseError: DatabaseError?,
                    committed: Boolean,
                    currentData: DataSnapshot?
                ) {
                    if (databaseError != null) {
                        Log.e("HomeAdapter", "Transaction failed.", databaseError.toException())
                    } else {
                        Log.d("HomeAdapter", "Transaction successful. Committed: $committed")
                        updateStarIcon(holder.ivStar, committed) // Update the star icon based on the transaction result
                    }
                }
            })
        }

    }
        private fun addNewTopicGuest(topicId: String, userGuest: String, newStorageStatus: Boolean) {
        val topicGuestRef = FirebaseDatabase.getInstance().reference.child("topic_guest")
        val topicGuestId = "${topicId}_$userGuest"

        val topic = TopicGuest(
            topicGuestId = topicGuestId,
            topicId = topicId,
            userGuest = userGuest,
            score = 0,
            storage = newStorageStatus
        )

        topicGuestRef.child(topicGuestId).setValue(topic)
            .addOnSuccessListener {
                // Xử lý thành công nếu cần thiết
            }
            .addOnFailureListener { e ->
                // Xử lý thất bại nếu cần thiết
            }
    }




    private fun updateStarIcon(ivStar: ImageView, isStored: Boolean) {
        // Cập nhật màu sắc của sao dựa trên giá trị isStored
        if (isStored) {
            ivStar.setImageResource(R.drawable.baseline_star_yellow) // Thay đổi icon sao màu vàng
        } else {
            ivStar.setImageResource(R.drawable.baseline_star_24) // Thay đổi icon sao màu xám
        }
    }
    private fun updateStorageStatus(topicId: String, userGuest: String, isStorage: Boolean) {
        Log.d("HomeAdapter", "Đang cập nhật trạng thái storage cho topicId: $topicId, userGuest: $userGuest, isStorage: $isStorage")

        val topicGuestRef = FirebaseDatabase.getInstance().reference
            .child("topic_guest")
            .child("${topicId}_$userGuest") // Dòng được sửa đổi

        // Cập nhật trạng thái storage
        topicGuestRef.child("storage").setValue(isStorage)
            .addOnSuccessListener {
                // Xử lý thành công nếu cần thiết
                Log.d("HomeAdapter", "Cập nhật trạng thái storage thành công")
            }
            .addOnFailureListener { e ->
                // Xử lý thất bại nếu cần thiết
                Log.e("HomeAdapter", "Cập nhật trạng thái storage thất bại", e)
            }
    }



    override fun getItemCount(): Int {
        return topicList.size
    }
}
