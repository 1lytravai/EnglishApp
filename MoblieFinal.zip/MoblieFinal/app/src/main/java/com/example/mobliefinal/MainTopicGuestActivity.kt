package com.example.mobliefinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.example.mobliefinal.databinding.ActivityMainTopicGuestBinding
import com.example.mobliefinal.databinding.ActivityMainBinding

class MainTopicGuestActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainTopicGuestBinding
    lateinit var tvNameTopic: TextView
    private lateinit var btnAdd: Button
    private lateinit var topicId: String
    private lateinit var username: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainTopicGuestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tvNameTopic = findViewById(R.id.tvNameTopic)
        // Gán giá trị trực tiếp cho biến thành viên, không khai báo biến cục bộ mới
        topicId = intent.getStringExtra("topicId") ?: ""
        val topicName = intent.getStringExtra("topicName") ?: ""
        val userTopic = intent.getStringExtra("userTopic") ?: ""
        username = intent.getStringExtra("username") ?: "" // Nhận dữ liệu currentUser từ Intent
        tvNameTopic.text = topicName

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        replaceFragment(FragmentWordGuest())

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }

        binding.bottomNavigation.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_main -> replaceFragment(FragmentWordGuest())
                R.id.nav_learn -> replaceFragment(FragmentLearnGuest())
                R.id.nav_rank -> replaceFragment(FragmentMainRank(topicId, username))
                //fragment learn
                else -> {
                }
            }
            true
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val bundle = Bundle().apply {
            putString("topicId", topicId)
            putString("username", username)
        }

        fragment.arguments = bundle

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()

        // Kiểm tra kiểu của fragment trước khi thay thế
        if (fragment is FragmentMainRank) {
            // Nếu đó là FragmentMainRank, tạo một thể hiện mới với các đối số
            val mainRankFragment = FragmentMainRank(topicId, username)
            fragmentTransaction.replace(R.id.fragmentContainerView, mainRankFragment)
        } else {
            // Ngược lại, thay thế bằng fragment ban đầu
            fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
        }

        fragmentTransaction.commit()
    }
}
