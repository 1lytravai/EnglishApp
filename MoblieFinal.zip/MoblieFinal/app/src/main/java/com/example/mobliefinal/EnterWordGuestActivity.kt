package com.example.mobliefinal

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.firebase.database.*

class EnterWordGuestActivity : AppCompatActivity() {

    private lateinit var tvWord: TextView
    private lateinit var etUserInput: EditText
    private lateinit var btnSubmit: Button
    private lateinit var container: RelativeLayout

    private var wordList: MutableList<Word> = mutableListOf()
    private var currentWordIndex: Int = 0
    private lateinit var databaseReference: DatabaseReference
    private val handler = Handler()

    private var correctAnswers: Int = 0
    private var incorrectAnswers: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_word_guest)

        tvWord = findViewById(R.id.tvWord)
        etUserInput = findViewById(R.id.etUserInput)
        btnSubmit = findViewById(R.id.btnSubmit)
        container = findViewById(R.id.container)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }
        // Lấy reference của cơ sở dữ liệu "words"
        databaseReference = FirebaseDatabase.getInstance().getReference("words")

        // Lấy topicId từ Intent
        val topicId = intent.getStringExtra("topicId")
        val username = intent.getStringExtra("username")

        // Lấy danh sách từ vựng

        val isFavorite = intent.getBooleanExtra("favorite", false)

        if (isFavorite) {
            fetchWordsList(topicId)
        } else {
            // Fetch all flashcards
            fetchMeaningList(topicId)
        }

        btnSubmit.setOnClickListener {
            checkAnswer(topicId)
        }
    }
    private fun updateLearnedForGuest(topicId: String?, username: String) {
        topicId?.let {
            val topicGuestRef = FirebaseDatabase.getInstance().getReference("topic_guest")
            val topicGuestId = "${topicId}_$username"

            // Thực hiện truy vấn để lấy node tương ứng với topicGuestId
            val query = topicGuestRef.orderByChild("topicGuestId").equalTo(topicGuestId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Có ít nhất một node tồn tại với topicGuestId tương ứng
                        dataSnapshot.children.forEach { childSnapshot ->
                            val topicGuestId = childSnapshot.key ?: ""
                            val learned = childSnapshot.child("learned").getValue(Long::class.java) ?: 0

                            // Cộng thêm 1 đơn vị cho trường learned và cập nhật vào Firebase
                            val newLearned = learned + 1
                            updateLearnedFieldForGuest(topicGuestId, newLearned)
                        }
                    } else {
                        // Node không tồn tại, có thể xử lý tùy ý tại đây
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi khi truy vấn không thành công
                }
            })
        }
    }
    private fun updateLearnedFieldForGuest(topicGuestId: String, newLearned: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().getReference("topic_guest").child(topicGuestId)

        // Cập nhật trường learned của node
        topicGuestRef.child("learned").setValue(newLearned)
            .addOnSuccessListener {
                // Cập nhật thành công
            }
            .addOnFailureListener {
                // Xử lý khi cập nhật thất bại
            }
    }
    private fun updateTopicGuestScore(topicId: String, username: String, newScore: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().reference
            .child("topic_guest")

        // Thực hiện truy vấn để lấy node tương ứng với topicId và username
        val query = topicGuestRef.orderByChild("topicGuestId").equalTo("${topicId}_$username")

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Có ít nhất một node tồn tại với topicId và userGuest tương ứng
                    dataSnapshot.children.forEach { childSnapshot ->
                        val topicGuestId = childSnapshot.key ?: ""
                        val currentScore = childSnapshot.child("score").getValue(Long::class.java) ?: 0

                        // Check if the new score is higher than the current score before updating
                        if (newScore > currentScore) {
                            // Cập nhật trường score của node
                            updateScoreForTopicGuest(topicGuestId, newScore)
                        } else {
                        }
                    }
                } else {

                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi khi truy vấn không thành công
            }
        })
    }


    private fun updateScoreForTopicGuest(topicGuestId: String, newScore: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().reference
            .child("topic_guest")
            .child(topicGuestId)

        // Cập nhật trường score của node
        topicGuestRef.child("score").setValue(newScore)
            .addOnSuccessListener {
                // Cập nhật thành công
            }
            .addOnFailureListener {
                // Xử lý khi cập nhật thất bại
            }
    }
    private fun fetchWordsList(topicId: String?) {
        // Truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayWord()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle the error if the query is not successful
                // Toast.makeText(this@EnterWordActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun fetchMeaningList(topicId: String?) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")

        // Truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordList.clear()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        wordList.add(word)
                    }
                }

                // Hiển thị từ vựng đầu tiên
                if (wordList.isNotEmpty()) {
                    shuffleWordList()
                    displayMeaningAndWords()
                } else {
                    // Nếu không có từ vựng, hiển thị kết quả cuối cùng
                    showFinalResults()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle the error if the query is not successful
                // Toast.makeText(this@EnterWordActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun displayMeaningAndWords() {
        // Hiển thị nghĩa từ (meaning)
        val meaningTextView: TextView = findViewById(R.id.tvWord)
        meaningTextView.text = wordList[currentWordIndex].meaning

        btnSubmit.setOnClickListener {
            checkWord()
        }
    }

    private fun checkWord() {
        val userInput = etUserInput.text.toString().trim()
        val correctWord = wordList[currentWordIndex].word.trim()

        // Check if the entered word is correct
        val isCorrect = userInput.equals(correctWord, ignoreCase = true)

        // Set background color based on correctness
        val backgroundColor = if (isCorrect) Color.GREEN else Color.RED
        container.setBackgroundColor(backgroundColor)

        // Increment the counters based on correctness
        if (isCorrect) {
            correctAnswers++
        } else {
            incorrectAnswers++
        }

        // Delay for 1 second and then move to the next word or show final results
        handler.postDelayed({
            // Reset background color
            container.setBackgroundColor(Color.TRANSPARENT)

            // Move to the next word or show final results
            currentWordIndex++
            if (currentWordIndex < wordList.size) {
                displayMeaningAndWords()
            } else {
                showFinalResults()
            }
        }, 1000)

        etUserInput.text.clear()
    }

    private fun displayWord() {
        // Hiển thị từ (word)
        tvWord.text = wordList[currentWordIndex].word
    }


    private fun checkAnswer(topicId: String?) {
        val userInput = etUserInput.text.toString().trim()
        val isCorrect = userInput.equals(wordList[currentWordIndex].meaning, ignoreCase = true)

        // Set background color based on correctness
        val backgroundColor = if (isCorrect) Color.GREEN else Color.RED
        container.setBackgroundColor(backgroundColor)

        // Increment the counters based on correctness
        if (isCorrect) {
            correctAnswers++


        } else {
            incorrectAnswers++

        }

        // Delay for 1 second and then move to the next word or show final results
        handler.postDelayed({
            // Reset background color
            container.setBackgroundColor(Color.TRANSPARENT)

            // Move to the next word or show final results
            currentWordIndex++
            if (currentWordIndex < wordList.size) {
                displayWord()
            } else {
                showFinalResults()
            }
        }, 1000)

        etUserInput.text.clear()
    }


    private fun showFinalResults() {
        val topicId = intent.getStringExtra("topicId")?: ""
        val username = intent.getStringExtra("username")?: ""

        updateTopicGuestScore(topicId, username, correctAnswers.toLong())
        updateLearnedForGuest(topicId, username)
        updateLearnedForTopic(topicId)


        val resultMessage = "Number of correct: $correctAnswers\nNumber of wrong: $incorrectAnswers"

        val alertDialog = AlertDialog.Builder(this@EnterWordGuestActivity)
            .setTitle("Result")
            .setMessage(resultMessage)
            .setPositiveButton("OK") { _, _ ->


                val resultMessage = "Number of correct: $correctAnswers\nNumber of wrong: $incorrectAnswers"

                val intent = Intent(this@EnterWordGuestActivity, MainActivity::class.java)
                startActivity(intent)
            }
            .create()
        alertDialog.show()
    }
    private fun updateLearnedForTopic(topicId: String?) {
        topicId?.let {
            val topicsReference = FirebaseDatabase.getInstance().getReference("topics")
            val query = topicsReference.orderByChild("topicId").equalTo(topicId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (topicSnapshot in dataSnapshot.children) {
                        val learned = topicSnapshot.child("learned").getValue(Long::class.java) ?: 0
                        topicsReference.child(topicSnapshot.key ?: "").child("learned").setValue(learned + 1)
                            .addOnSuccessListener {
                                // Cập nhật thành công
                            }
                            .addOnFailureListener {
                                // Xử lý khi cập nhật thất bại
                            }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi nếu có
                }
            })
        }
    }

    private fun shuffleWordList() {
        wordList.shuffle()
    }

}
