package com.example.mobliefinal

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment

class EnterWordDialogFragmentGuest : DialogFragment() {
    private lateinit var btnEng: Button
    private lateinit var btnViet: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_enter_word_dialog_guest, container, false)

        btnEng = view.findViewById(R.id.btnEng)
        btnViet = view.findViewById(R.id.btnViet)

        // Retrieve data from arguments
        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val username = arguments?.getString("username")


        btnEng.setOnClickListener {
            val intent = Intent(requireContext(), EnterWordGuestActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("username", username)
            intent.putExtra("favorite", false) // Set to false for normal flashcards
            startActivity(intent)
            dismiss()
        }
        btnViet.setOnClickListener {
            val intent = Intent(requireContext(), EnterWordGuestActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("username", username)
            intent.putExtra("favorite", true) // Set to true for favorite flashcards
            startActivity(intent)
            dismiss() // Close the dialog after handling the click
        }

        // Add any logic for the "Favorite" button if needed

        return view
    }

}