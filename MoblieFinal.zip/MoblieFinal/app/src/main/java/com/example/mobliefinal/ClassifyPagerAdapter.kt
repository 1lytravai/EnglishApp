package com.example.mobliefinal

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentStatePagerAdapter

class ClassifyPagerAdapter(fm: FragmentManager, private val topicId: String) : FragmentStatePagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> FragmentLearned.newInstance(topicId)
            1 -> FragmentMemorized.newInstance(topicId)
            2 -> FragmentNoLearned.newInstance(topicId)
            else -> throw IllegalArgumentException("Invalid position: $position")
        }
    }

    override fun getCount(): Int {
        return 3
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Learned"
            1 -> "Memorized"
            2 -> "Haven't Studied yet"
            else -> null
        }
    }
}
