package com.example.mobliefinal

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class StorageAdapter(private val activity: Activity,
    ) :
    RecyclerView.Adapter<StorageAdapter.StorageViewHolder>() {

    private var topicList: List<Topic> = emptyList()
    private lateinit var username: String

    fun addTopic(topic: Topic) {
        topicList = topicList + listOf(topic)
        notifyDataSetChanged()
    }

    class StorageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView)
        val userNameTextView: TextView = itemView.findViewById(R.id.userNameTextView)
        val ivStar: ImageView = itemView.findViewById(R.id.ivStar)
        val cardView: LinearLayout = itemView.findViewById(R.id.cardView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StorageViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_storage, parent, false)
        return StorageViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: StorageViewHolder, position: Int) {
        val topic = topicList[position]
        holder.nameTextView.text = topic.name
        holder.descriptionTextView.text = topic.description
        holder.userNameTextView.text = topic.user


        holder.ivStar.setOnClickListener {

        }
    }

    override fun getItemCount(): Int {
        return topicList.size
    }

    fun setUsername(username: String) {
        this.username = username
    }
}
