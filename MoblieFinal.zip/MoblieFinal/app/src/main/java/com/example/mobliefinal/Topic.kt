package com.example.mobliefinal

import com.google.firebase.database.ServerValue

class Topic(
    val topicId: String? = null,
    val name: String = "",
    var learned: Long = 0,
    val description: String = "",
    val user: String = "",
    val public: Boolean = false,
    var createTime: Any = ServerValue.TIMESTAMP,
    val folder: String = "",
)


