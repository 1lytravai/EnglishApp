package com.example.mobliefinal

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FlashCardGuestAdapter(
    private val words: List<Word>,
    private val viewPager: ViewPager,
    private val learningProgressListener: LearningProgressListener,
    private val topicId: String,
    private val username: String
) : PagerAdapter() {

    private var currentPosition: Int = 0

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val view = LayoutInflater.from(container.context).inflate(R.layout.flashcard_item, container, false)

        val wordTextView: TextView = view.findViewById(R.id.tvFront)
        val meaningTextView: TextView = view.findViewById(R.id.tvBack)
        val nextButton: Button = view.findViewById(R.id.nextButton)
        val cardViewFront: LinearLayout = view.findViewById(R.id.cardViewFront)
        val cardViewBack: LinearLayout = view.findViewById(R.id.cardViewBack)

        val word = words[position]

        // Kiểm tra trạng thái để xác định nên hiển thị từ vựng hay nghĩa
        if (word.back) {
            wordTextView.visibility = View.GONE
            meaningTextView.text = word.meaning
            cardViewFront.visibility = View.GONE
            cardViewBack.visibility = View.VISIBLE
        } else {
            wordTextView.text = word.word
            meaningTextView.visibility = View.GONE
            cardViewFront.visibility = View.VISIBLE
            cardViewBack.visibility = View.GONE
        }

        // Xử lý sự kiện khi người dùng nhấn vào mặt trước
        cardViewFront.setOnClickListener {
            val currentWord = words[position]
            Log.d("FlashCardAdapter", "Front Clicked: ${currentWord.wordId}, Front: ${currentWord.back}")
            currentWord.back = true // Chuyển sang mặt sau
            currentWord.learn = true


            // Ẩn từ vựng, hiển thị nghĩa
            wordTextView.visibility = View.GONE
            wordTextView.text = "" // Đảm bảo nghĩa rỗng
            meaningTextView.text = currentWord.meaning
            meaningTextView.visibility = View.VISIBLE
            cardViewFront.visibility = View.GONE
            cardViewBack.visibility = View.VISIBLE

            updateUI()
        }

        // Xử lý sự kiện khi người dùng nhấn vào mặt sau
        cardViewBack.setOnClickListener {
            val currentWord = words[position]
            Log.d("FlashCardAdapter", "Back Clicked: ${currentWord.wordId}, Back: ${currentWord.back}")
            currentWord.back = false // Chuyển sang mặt trước

            // Hiển thị từ vựng, ẩn nghĩa
            wordTextView.text = currentWord.word
            wordTextView.visibility = View.VISIBLE
            meaningTextView.text = "" // Đảm bảo nghĩa rỗng
            meaningTextView.visibility = View.GONE
            cardViewFront.visibility = View.VISIBLE
            cardViewBack.visibility = View.GONE

            updateUI()
        }

        val backButton: Button = view.findViewById(R.id.backButton)
        backButton.setOnClickListener {
            if (position > 0) {
                viewPager.setCurrentItem(position - 1, true)
            }
        }
        // Xử lý sự kiện khi nút "Next" được nhấn
        nextButton.setOnClickListener {
            // Chuyển đến từ vựng tiếp theo
            val currentWord = words[position]
            currentWord.back = false // Chuyển sang mặt trước

            if (position < words.size - 1) {
                viewPager.setCurrentItem(position + 1, true)
            } else {

                // Nếu đang ở trang cuối cùng, hiển thị DialogFragment
                updateLearnedForTopics(topicId)
                updateLearnedForGuest(topicId, username)
                val learnCompletedDialog = LearnCompletedDialogFragment()
                learnCompletedDialog.show((view.context as AppCompatActivity).supportFragmentManager, "LearnCompletedDialog")
            }
        }

        container.addView(view)
        return view
    }
    interface LearningProgressListener {
        fun onLearningProgressChanged()
    }
    private fun updateLearnedForGuest(topicId: String?, username: String) {
        Log.d("FlashCardGuestAdapter", "Topic ID to update: $topicId") // Log giá trị topicId
        topicId?.let {
            val topicGuestRef = FirebaseDatabase.getInstance().getReference("topic_guest")
            val topicGuestId = "${topicId}_$username"

            val query = topicGuestRef.orderByChild("topicGuestId").equalTo(topicGuestId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Có ít nhất một node tồn tại với topicGuestId tương ứng
                        for (topicGuestSnapshot in dataSnapshot.children) {
                            val learned = topicGuestSnapshot.child("learned").getValue(Long::class.java) ?: 0
                            topicGuestRef.child(topicGuestSnapshot.key ?: "").child("learned").setValue(learned + 1)
                        }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi nếu có
                }
            })
        }
    }


    fun getCurrentPosition(): Int {
        return currentPosition
    }

    private fun updateLearnedForTopics(topicId: String?) {
        Log.d("FlashCardGuestAdapter", "Topic ID to update: $topicId") // Log giá trị topicId
        topicId?.let {
            val topicsReference = FirebaseDatabase.getInstance().getReference("topics")
            val query = topicsReference.orderByChild("topicId").equalTo(topicId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (topicSnapshot in dataSnapshot.children) {
                        val learned = topicSnapshot.child("learned").getValue(Long::class.java) ?: 0
                        topicsReference.child(topicSnapshot.key ?: "").child("learned").setValue(learned + 1)
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi nếu có
                }
            })
        }
    }

    private fun updateUI() {
        learningProgressListener.onLearningProgressChanged()
        notifyDataSetChanged()
        viewPager.adapter?.notifyDataSetChanged()
    }
    override fun getCount(): Int {
        return words.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }
}