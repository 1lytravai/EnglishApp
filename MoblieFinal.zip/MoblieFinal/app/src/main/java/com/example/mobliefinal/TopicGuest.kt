package com.example.mobliefinal

import com.google.firebase.database.ServerValue

data class TopicGuest(
    val topicGuestId: String = "",
    val topicId: String = "",
    val userGuest: String = "",
    val score: Int = 0,
    val learned: Int = 0,
    var storage: Boolean = false
)
