package com.example.mobliefinal

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.mobliefinal.databinding.FragmentLearnBinding
import com.example.mobliefinal.databinding.FragmentLearnGuestBinding
import com.example.mobliefinal.databinding.FragmentTopicBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class FragmentLearnGuest : Fragment() {
    private lateinit var databaseReference: DatabaseReference
    private lateinit var sharedPreferences: SharedPreferences
    private var _binding: FragmentLearnGuestBinding? = null
    private lateinit var btnFlashcard: Button
    private lateinit var btnMultiple: Button
    private lateinit var btnEnter: Button
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentLearnGuestBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Kiểm tra và đảm bảo binding không phải là null
        if (_binding == null) {
            // Xử lý khi binding là null
            return
        }

        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val username = arguments?.getString("username")


        btnFlashcard = binding.btnFlashCard
        btnMultiple = binding.btnMultiple
        btnEnter = binding.btnEnterWord


        btnFlashcard.setOnClickListener {
            val intent = Intent(requireContext(), FlashCardGuestActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("username", username)
            intent.putExtra("favorite", false) // Set to false for normal flashcards
            startActivity(intent)
        }

        btnMultiple.setOnClickListener{
            val dialogFragment = MultipleDialogFragmentGuest()

            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            args.putString("username", username)

            dialogFragment.arguments = args

            dialogFragment.show(parentFragmentManager, "MultipleDialog")
        }

        btnEnter.setOnClickListener{

            val dialogFragment = EnterWordDialogFragmentGuest()

            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            args.putString("username", username)

            dialogFragment.arguments = args

            dialogFragment.show(parentFragmentManager, "EnterDialog")

        }
    }
}