package com.example.mobliefinal

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobliefinal.databinding.ActivityMainTopicBinding
import com.example.mobliefinal.databinding.FragmentFavoriteBinding
import com.example.mobliefinal.databinding.FragmentLearnedBinding
import com.example.mobliefinal.databinding.FragmentMemorizedBinding
import com.example.mobliefinal.databinding.FragmentNoLearnedBinding
import com.example.mobliefinal.databinding.FragmentTopicBinding
import com.example.mobliefinal.databinding.FragmentWordBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FragmentNoLearned : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var wordList: ArrayList<Word>
    private lateinit var wordAdapter: WordAdapter
    private var _binding: FragmentNoLearnedBinding? = null
    private lateinit var databaseReference: DatabaseReference
    private val binding get() = _binding!!

    companion object {
        fun newInstance(topicId: String): FragmentNoLearned {
            val fragment = FragmentNoLearned()
            val args = Bundle()
            args.putString("topicId", topicId)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNoLearnedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val user = arguments?.getString("user")
        Log.d("FragmentNoLearned", "topicId: $topicId")

        recyclerView = binding.recyclerViewWord
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        databaseReference = FirebaseDatabase.getInstance().reference.child("words")

        wordList = ArrayList()
        wordAdapter = WordAdapter(requireActivity(), wordList)
        recyclerView.adapter = wordAdapter
        Log.d("FragmentNoLearned", "topicId: $topicId")

            databaseReference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    wordList.clear()
                    for (postSnapshot in snapshot.children) {
                        val word = postSnapshot.getValue(Word::class.java)
                        word?.let {
                            // Thêm vào danh sách chỉ khi topic trùng với topicId và chưa học
                            if (it.topic == topicId && !it.learn) {
                                wordList.add(it)
                            }
                        }
                    }
                    wordAdapter.notifyDataSetChanged() // Cập nhật adapter sau khi danh sách thay đổi
                }

                override fun onCancelled(error: DatabaseError) {
                    // Xử lý lỗi
                }
            })
        }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
