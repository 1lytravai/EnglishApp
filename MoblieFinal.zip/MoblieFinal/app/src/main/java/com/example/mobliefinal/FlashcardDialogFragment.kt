package com.example.mobliefinal

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment

class FlashcardDialogFragment : DialogFragment() {
    private lateinit var btnNormal: Button
    private lateinit var btnFavorite: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.flashcard_dialog, container, false)

        btnNormal = view.findViewById(R.id.btnNormal)
        btnFavorite = view.findViewById(R.id.btnFavorite)

        // Retrieve data from arguments
        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val user = arguments?.getString("user")


        btnNormal.setOnClickListener {
            // Handle the "Normal" button click with the passed data
            // For example, start the Flashcard activity with the data
            val intent = Intent(requireContext(), FlashCardActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("user", user)
            intent.putExtra("favorite", false) // Set to false for normal flashcards
            startActivity(intent)
            dismiss()
        }
        btnFavorite.setOnClickListener {
            val intent = Intent(requireContext(), FlashCardActivity::class.java)
            intent.putExtra("topicId", topicId)
            intent.putExtra("topicName", topicName)
            intent.putExtra("user", user)
            intent.putExtra("favorite", true) // Set to true for favorite flashcards
            startActivity(intent)
            dismiss() // Close the dialog after handling the click
        }

        // Add any logic for the "Favorite" button if needed

        return view
    }

}
