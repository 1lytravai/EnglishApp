package com.example.mobliefinal

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment


class LearnCompletedDialogFragment : DialogFragment() {
    companion object {
        fun newInstance(topicId: String, topicName: String): LearnCompletedDialogFragment {
            val fragment = LearnCompletedDialogFragment()
            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            fragment.arguments = args
            return fragment
        }
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("Học xong")
            .setMessage("Chúc mừng! Bạn đã học xong topic này.")
            .setPositiveButton("Tiếp tục") { dialog, _ ->
                // Đóng dialog và chuyển về trang MainTopicActivity
                dialog.dismiss()
                val intent = Intent(requireContext(), MainActivity::class.java)
                startActivity(intent)
            }
            .create()
    }
}

