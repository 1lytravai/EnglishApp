package com.example.mobliefinal

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MultipleChoiceGuestActivity : AppCompatActivity() {

    // Khai báo biến và UI elements cần thiết
    private lateinit var tvWord: TextView
    private lateinit var btnOption1: Button
    private lateinit var btnOption2: Button
    private lateinit var btnOption3: Button
    private lateinit var btnOption4: Button
    private lateinit var btnOptions: Array<Button>
    private lateinit var btnNext: Button
    private lateinit var btnNext2: Button


    // Thêm khai báo danh sách từ vựng ở mức lớp
    private lateinit var wordsList: List<Word>
    private var currentIndex = 0
    private var correctAnswers = 0
    private var wrongAnswers = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multiple_choice_guest)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }

        // Khởi tạo UI elements
        tvWord = findViewById(R.id.tvWord)
        btnNext = findViewById(R.id.btnNext)
        btnNext2 = findViewById(R.id.btnNext2)


        val isEnglish = intent.getBooleanExtra("eng", false)

        btnOptions = arrayOf(
            findViewById(R.id.btnOption1),
            findViewById(R.id.btnOption2),
            findViewById(R.id.btnOption3),
            findViewById(R.id.btnOption4)
        )


        // Lấy topicId từ intent
        val topicId = intent.getStringExtra("topicId")
        val username = intent.getStringExtra("username")
//        displayQuestion(wordsList[currentIndex])

        // Truy vấn Firebase Realtime Database để lấy danh sách các từ vựng thuộc chủ đề
        if (isEnglish) {
            // Fetch favorite flashcards
            fetchWordsMeaning(topicId)
            btnNext.isEnabled = false
        } else {
            // Fetch all flashcards
            fetchWordsFromFirebase(topicId)
            btnNext2.isEnabled = false

        }

        btnNext.setOnClickListener {
            // Chuyển sang câu hỏi tiếp theo
            currentIndex++
            if (currentIndex < wordsList.size) {
                displayQuestion(wordsList[currentIndex])
                isEnable()
            } else {
                // Nếu đã hiển thị hết câu hỏi, bạn có thể thực hiện hành động khác tùy vào yêu cầu của bạn.
                showQuizSummary()
            }
        }

        btnNext2.setOnClickListener {
            // Chuyển sang câu hỏi tiếp theo
            currentIndex++
            if (currentIndex < wordsList.size) {
                displayQuestionMeaning(wordsList[currentIndex])
                isEnable()
            } else {
                // Nếu đã hiển thị hết câu hỏi, bạn có thể thực hiện hành động khác tùy vào yêu cầu của bạn.
                showQuizSummary()
            }
        }
    }

    private fun fetchWordsFromFirebase(topicId: String?) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")

        // Thực hiện truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordsList = mutableListOf()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        (wordsList as MutableList<Word>).add(word)
                    }
                }

                // Kiểm tra xem danh sách từ vựng có rỗng hay không
                if (wordsList.isNotEmpty()) {
                    // Hiển thị câu hỏi đầu tiên
                    displayQuestion(wordsList.random())
                } else {
                    // Handle the case when there are no words for the specified topic
                    Toast.makeText(this@MultipleChoiceGuestActivity, "No words found for the specified topic", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi khi truy vấn không thành công
                Toast.makeText(this@MultipleChoiceGuestActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun updateLearnedForGuest(topicId: String?, username: String) {
        topicId?.let {
            val topicGuestRef = FirebaseDatabase.getInstance().getReference("topic_guest")
            val topicGuestId = "${topicId}_$username"

            // Thực hiện truy vấn để lấy node tương ứng với topicGuestId
            val query = topicGuestRef.orderByChild("topicGuestId").equalTo(topicGuestId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Có ít nhất một node tồn tại với topicGuestId tương ứng
                        dataSnapshot.children.forEach { childSnapshot ->
                            val topicGuestId = childSnapshot.key ?: ""
                            val learned = childSnapshot.child("learned").getValue(Long::class.java) ?: 0

                            // Cộng thêm 1 đơn vị cho trường learned và cập nhật vào Firebase
                            val newLearned = learned + 1
                            updateLearnedFieldForGuest(topicGuestId, newLearned)
                        }
                    } else {
                        // Node không tồn tại, có thể xử lý tùy ý tại đây
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi khi truy vấn không thành công
                }
            })
        }
    }

    private fun updateLearnedFieldForGuest(topicGuestId: String, newLearned: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().getReference("topic_guest").child(topicGuestId)

        // Cập nhật trường learned của node
        topicGuestRef.child("learned").setValue(newLearned)
            .addOnSuccessListener {
                // Cập nhật thành công
            }
            .addOnFailureListener {
                // Xử lý khi cập nhật thất bại
            }
    }


    private fun updateTopicGuestScore(topicId: String, username: String, newScore: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().reference
            .child("topic_guest")

        // Thực hiện truy vấn để lấy node tương ứng với topicId và username
        val query = topicGuestRef.orderByChild("topicGuestId").equalTo("${topicId}_$username")

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Có ít nhất một node tồn tại với topicId và userGuest tương ứng
                    dataSnapshot.children.forEach { childSnapshot ->
                        val topicGuestId = childSnapshot.key ?: ""
                        val currentScore = childSnapshot.child("score").getValue(Long::class.java) ?: 0

                        // Check if the new score is higher than the current score before updating
                        if (newScore > currentScore) {
                            // Cập nhật trường score của node
                            updateScoreForTopicGuest(topicGuestId, newScore)
                        } else {

                        }
                    }
                } else {

                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi khi truy vấn không thành công
            }
        })
    }


    private fun updateScoreForTopicGuest(topicGuestId: String, newScore: Long) {
        val topicGuestRef = FirebaseDatabase.getInstance().reference
            .child("topic_guest")
            .child(topicGuestId)

        // Cập nhật trường score của node
        topicGuestRef.child("score").setValue(newScore)
            .addOnSuccessListener {
                // Cập nhật thành công
            }
            .addOnFailureListener {
                // Xử lý khi cập nhật thất bại
            }
    }

    private fun fetchWordsMeaning(topicId: String?) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("words")

        // Thực hiện truy vấn Firebase để lấy danh sách từ vựng thuộc topic
        databaseReference.orderByChild("topic").equalTo(topicId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                wordsList = mutableListOf()
                for (wordSnapshot in dataSnapshot.children) {
                    val word = wordSnapshot.getValue(Word::class.java)
                    if (word != null) {
                        (wordsList as MutableList<Word>).add(word)
                    }
                }

                // Kiểm tra xem danh sách từ vựng có rỗng hay không
                if (wordsList.isNotEmpty()) {
                    // Hiển thị câu hỏi đầu tiên
                    displayQuestionMeaning(wordsList.random())
                } else {
                    // Handle the case when there are no words for the specified topic
                    Toast.makeText(this@MultipleChoiceGuestActivity, "No words found for the specified topic", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Xử lý lỗi khi truy vấn không thành công
                Toast.makeText(this@MultipleChoiceGuestActivity, "Error fetching data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showQuizSummary() {
        // Initialize variables to store correct and incorrect words
        val correctWords = mutableListOf<Word>()
        val incorrectWords = mutableListOf<Word>()

        val topicId = intent.getStringExtra("topicId")?: ""
        val username = intent.getStringExtra("username")?: ""

        updateTopicGuestScore(topicId, username, correctAnswers.toLong())
        updateLearnedForTopic(topicId)
        updateLearnedForGuest(topicId, username)
        // Iterate through the wordsList to categorize correct and incorrect words
        for (word in wordsList) {
            if (word.correct) {
                correctWords.add(word)
            } else {
                incorrectWords.add(word)
            }
        }

        // Convert correctAnswers and wrongAnswers to strings
        val correctAnswersString = correctAnswers.toString()
        val wrongAnswersString = wrongAnswers.toString()

        // Build messages for correct and incorrect words
        val correctMessage = if (correctWords.isNotEmpty()) {
            "The words you answer correctly:\n${correctWords.joinToString(separator = ", ") { it.word }}"
        } else {
            "There are no words you answered correctly."
        }

        val incorrectMessage = if (incorrectWords.isNotEmpty()) {
            "The words you answer wrong:\n${incorrectWords.joinToString(separator = ", ") { it.word }}"
        } else {
            "There are no words you answered wrong."
        }

        // Display a message with the number of correct and wrong answers, along with correct and incorrect words
        val summaryMessage = "Number of correct: $correctAnswersString\nNumber of wrong: $wrongAnswersString\n\n$correctMessage\n\n$incorrectMessage"

        val alertDialog = AlertDialog.Builder(this)
            .setMessage(summaryMessage)
            .setPositiveButton("OK") { dialog, _ ->

                // Close the dialog when OK is pressed
                val intent = Intent(this@MultipleChoiceGuestActivity, MainActivity::class.java)
                startActivity(intent)
                dialog.dismiss()

                // Perform other actions if needed
            }
            .create()

        alertDialog.show()
    }

    private fun updateLearnedForTopic(topicId: String?) {
        topicId?.let {
            val topicsReference = FirebaseDatabase.getInstance().getReference("topics")
            val query = topicsReference.orderByChild("topicId").equalTo(topicId)

            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (topicSnapshot in dataSnapshot.children) {
                        val learned = topicSnapshot.child("learned").getValue(Long::class.java) ?: 0
                        topicsReference.child(topicSnapshot.key ?: "").child("learned").setValue(learned + 1)
                            .addOnSuccessListener {
                                // Cập nhật thành công
                                Toast.makeText(this@MultipleChoiceGuestActivity, "Updated 'learned' field successfully", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener {
                                // Xử lý khi cập nhật thất bại
                                Toast.makeText(this@MultipleChoiceGuestActivity, "Failed to update 'learned' field", Toast.LENGTH_SHORT).show()
                            }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý lỗi nếu có
                    Toast.makeText(this@MultipleChoiceGuestActivity, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }


    private fun displayQuestion(word: Word) {
        // Hiển thị từ và các ý nghĩa tương ứng lên giao diện
        tvWord.text = word.word

        // Tạo một danh sách ý nghĩa, bao gồm ý nghĩa đúng và ý nghĩa sai
        val meanings = mutableListOf<String>()
        meanings.add(word.meaning) // Ý nghĩa đúng
        // Thêm ba ý nghĩa sai (lấy ngẫu nhiên từ các từ vựng khác trong danh sách)
        val shuffledWords = wordsList.filter { it != word }.shuffled().take(3)
        meanings.addAll(shuffledWords.map { it.meaning })

        // Xáo trộn danh sách ý nghĩa
        val shuffledMeanings = meanings.shuffled()

        // Hiển thị các ý nghĩa xáo trộn lên các nút tương ứng
        for (i in btnOptions.indices) {
            btnOptions[i].text = shuffledMeanings[i]
            btnOptions[i].setOnClickListener {
                // Xử lý câu trả lời của người dùng
                checkAnswer(btnOptions[i].text.toString(), word)
            }
        }
    }
    private fun displayQuestionMeaning(word: Word) {
        // Hiển thị từ và các ý nghĩa tương ứng lên giao diện
        tvWord.text = word.meaning

        // Tạo một danh sách từ vựng, bao gồm từ vựng đúng và từ vựng sai
        val words = mutableListOf<String>()
        words.add(word.word) // Từ vựng đúng
        // Thêm ba từ vựng sai (lấy ngẫu nhiên từ các từ vựng khác trong danh sách)
        val shuffledWords = wordsList.filter { it != word }.shuffled().take(3)
        words.addAll(shuffledWords.map { it.word })

        // Xáo trộn danh sách từ vựng
        val shuffledWordsList = words.shuffled()

        // Hiển thị các từ vựng xáo trộn lên các nút tương ứng
        for (i in btnOptions.indices) {
            btnOptions[i].text = shuffledWordsList[i]
            btnOptions[i].setOnClickListener {
                // Xử lý câu trả lời của người dùng
                checkAnswerMeaning(btnOptions[i].text.toString(), word)
            }
        }
    }

    private fun disableAllButtons() {
        for (button in btnOptions) {
            button.isEnabled = false
        }
    }

    private fun isEnable() {
        for (button in btnOptions) {
            button.isEnabled = true
        }
    }


    private fun checkAnswer(selectedAnswer: String, word: Word) {
        val isCorrect = selectedAnswer == word.meaning
        val message = if (isCorrect) {
            "CORRECT!"
        } else {
            "WRONG. Correct answer is ${word.meaning}"
        }

        // Update the correct and wrong answers
        if (isCorrect) {
            correctAnswers++
        } else {
            wrongAnswers++
        }
        disableAllButtons()


        // Display the dialog with the correct/wrong message
        showAnswerDialog(message)
    }
    private fun checkAnswerMeaning(selectedAnswer: String, word: Word) {
        val isCorrect = selectedAnswer == word.word
        val message = if (isCorrect) {
            "CORRECT!"
        } else {
            "WRONG. Correct answer is ${word.word}"
        }

        // Update the correct and wrong answers
        if (isCorrect) {
            correctAnswers++
        } else {
            wrongAnswers++
        }
        disableAllButtons()

        // Display the dialog with the correct/wrong message
        showAnswerDialog(message)
    }




    private fun showAnswerDialog(message: String) {
        val alertDialog = AlertDialog.Builder(this)
            .setMessage(message)
            .create()

        alertDialog.show()

        // Sử dụng Handler để đóng dialog sau 3 giây
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            alertDialog.dismiss()
        }, 2000) // 3000 milliseconds = 3 seconds
    }
}

