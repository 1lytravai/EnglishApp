package com.example.mobliefinal

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.mobliefinal.databinding.FragmentLearnBinding
import com.example.mobliefinal.databinding.FragmentTopicBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class FragmentLearn : Fragment() {
    private lateinit var databaseReference: DatabaseReference
    private lateinit var sharedPreferences: SharedPreferences
    private var _binding: FragmentLearnBinding? = null
    private lateinit var btnFlashcard: Button
    private lateinit var btnMultiple: Button
    private lateinit var btnEnter: Button
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentLearnBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Kiểm tra và đảm bảo binding không phải là null
        if (_binding == null) {
            // Xử lý khi binding là null
            return
        }

        val topicId = arguments?.getString("topicId")
        val topicName = arguments?.getString("topicName")
        val user = arguments?.getString("user")


        btnFlashcard = binding.btnFlashCard
        btnMultiple = binding.btnMultiple
        btnEnter = binding.btnEnterWord


        btnFlashcard.setOnClickListener {
            val dialogFragment = FlashcardDialogFragment()

            // Pass data using a Bundle
            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            args.putString("user", user)

            dialogFragment.arguments = args

            dialogFragment.show(parentFragmentManager, "FlashcardDialog")
        }

        btnMultiple.setOnClickListener{
            val dialogFragment = MultipleDialogFragment()

            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            args.putString("user", user)

            dialogFragment.arguments = args

            dialogFragment.show(parentFragmentManager, "MultipleDialog")
        }

        btnEnter.setOnClickListener{
            val dialogFragment = EnterWordDialogFragment()

            // Pass data using a Bundle
            val args = Bundle()
            args.putString("topicId", topicId)
            args.putString("topicName", topicName)
            args.putString("user", user)

            dialogFragment.arguments = args

            dialogFragment.show(parentFragmentManager, "EnterDialog")

        }
    }
}