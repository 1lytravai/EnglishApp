// FragmentRank.kt

package com.example.mobliefinal

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mobliefinal.databinding.FragmentRankBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FragmentRank : Fragment() {
    private lateinit var binding: FragmentRankBinding
    private lateinit var userScoreAdapter: UserScoreAdapter

    private lateinit var topicId: String
    private lateinit var username: String
    private val databaseReference = FirebaseDatabase.getInstance().reference.child("topic_guest")

    companion object {
        fun newInstance(topicId: String, username: String): FragmentRank {
            val fragment = FragmentRank()
            val bundle = Bundle().apply {
                putString("topicId", topicId)
                putString("username", username)
            }
            fragment.arguments = bundle
            return fragment
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRankBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Nhận dữ liệu từ bundle (hoặc các phương thức khác tùy thuộc vào cách bạn truyền dữ liệu)
        val bundle = arguments
        if (bundle != null) {
            topicId = bundle.getString("topicId", "") ?: ""
            username = bundle.getString("username", "") ?: ""
        }

        // Log the values of topicId and username
        Log.d("FragmentRank", "topicId: $topicId, username: $username")

        // Initialize the adapter
        userScoreAdapter = UserScoreAdapter()

        // Set the adapter for the RecyclerView
        binding.recyclerViewWord.adapter = userScoreAdapter
        binding.recyclerViewWord.layoutManager = LinearLayoutManager(requireContext())

        // Thực hiện truy vấn vào Firebase để lấy danh sách user scores
        databaseReference.orderByChild("topicId").equalTo(topicId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val userScores = mutableListOf<TopicGuest>()

                    for (userSnapshot in dataSnapshot.children) {
                        val userScore = userSnapshot.getValue(TopicGuest::class.java)
                        userScore?.let {
                            userScores.add(it)
                        }
                    }

                    Log.d("FragmentRank", "userScores size: ${userScores.size}")

                    // Sắp xếp danh sách theo điểm số giảm dần
                    userScores.sortByDescending { it.score }

                    // Set the data for the adapter
                    userScoreAdapter.setData(userScores)
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Xử lý khi truy vấn không thành công
                    Log.e("FragmentRank", "Query cancelled: ${databaseError.message}")
                }
            })
    }
}
