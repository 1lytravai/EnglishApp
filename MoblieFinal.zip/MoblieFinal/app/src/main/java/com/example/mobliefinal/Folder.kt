package com.example.mobliefinal

class Folder (
            val folderId: String? = null,
            val createdAt: Long = 0,
            val description: String = "",
            val name: String = "",
            val public: Boolean = false,
            val user: String = ""
)
