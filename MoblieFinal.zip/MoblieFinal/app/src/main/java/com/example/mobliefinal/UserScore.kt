package com.example.mobliefinal

data class UserScore(
    val username: String? = null,
    val score: Long? = null
)
