package com.example.mobliefinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.example.mobliefinal.databinding.ActivityMainBinding
import com.example.mobliefinal.databinding.ActivityMainTopicBinding

class MainTopicActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainTopicBinding
    lateinit var tvNameTopic: TextView
    private lateinit var btnAdd: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainTopicBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tvNameTopic = findViewById(R.id.tvNameTopic)
        val topicId = intent.getStringExtra("topicId")
        val topicName = intent.getStringExtra("topicName")
        val userTopic = intent.getStringExtra("userTopic")
        val currentUser = intent.getStringExtra("user") // Nhận dữ liệu currentUser từ Intent
        tvNameTopic.text = topicName

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        replaceFragment(FragmentWord())

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        toolbar.setNavigationOnClickListener { onBackPressed() }


        binding.bottomNavigation.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_main -> replaceFragment(FragmentWord())
                R.id.nav_learn -> replaceFragment(FragmentLearn())
                R.id.nav_classfify -> replaceFragment(FragmentClassify())
                //fragment learn
                else -> {

                }
            }
            true
        }

    }
    private fun replaceFragment(fragment: Fragment) {
            val bundle = Bundle().apply {
                val topicId = intent.getStringExtra("topicId")
                val topicName = intent.getStringExtra("topicName")
                val userTopic = intent.getStringExtra("userTopic")
                val currentUser = intent.getStringExtra("user")
                putString("topicId", topicId)
                putString("topicName", topicName)
                putString("user", currentUser)
                putString("userTopic", userTopic)
            }

            fragment.arguments = bundle

            val fragmentManager = supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
            fragmentTransaction.commit()
        }

    }
